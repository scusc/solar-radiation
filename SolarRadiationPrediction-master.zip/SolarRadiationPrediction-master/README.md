# SolarRadiationPrediction


Predicting Solar Radiation using MLP ( Multi Layer Preceptron Model ) & GBR . GBR gave better results with 99.95% Accuracy .
